This font is for PERSONAL USE ONLY!

Duplicate, apply and use this font for commercial purposes
 WITHOUT PERMISSION or WITHOUT PURCHASE OF LICENSE
we as the Author or the Copyright Holder, will be charged a "Corporate License"

To purchase a commercial license, visit:

https://fontbundles.net/ndrienugrie
https://creativemarket.com/NUGS

Thanks for Download
Information about license please do not hesitate to contact me

ndrienugrie@gmail.com
Instagram : @ndrienugrie

Paypal account for donation : https://www.paypal.me/ndrienugrie